The position of the order is described by latitude and longitude.The distance between points uses a straight line distance
Time is represented by a timestamp.

pick_lng, pick_lat		represent the location of the restaurant
deliver_lng, deliver_lat	represent the location of the customer
assigned_time		represent the start time of an order
estimate_pick_time		represent the time when couriers can pick up meal
promise_deliver_time		represent promised delivery time. Exceeding this time is regarded as timeout, and there will be timeout loss
long-distance cross-regional	FALSE represents normal orders. TRUE represents long-distance cross-regional orders

Unacceptable time for each order is ten minutes after the promised delivery time
speed of courier:4 m/s
service time in each point: 3 min











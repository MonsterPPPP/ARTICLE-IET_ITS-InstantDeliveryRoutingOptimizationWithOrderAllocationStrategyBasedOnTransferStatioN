#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
from sklearn.cluster import DBSCAN
import matplotlib.pyplot as plt
import pandas as pd
import csv
data = []
fileName="big.csv"
in_df = pd.read_csv(fileName, header=0, nrows=145,
                    usecols=["pick_lng", "pick_lat","deliver_lng", "deliver_lat"])
data = in_df.values
data = np.array(data)
data.shape
#Data normalization

for i in range( data.shape[0]):
    for j in range (data.shape[1]):
        if(j%2==0):
            data[i][j]=(data[i][j]-121)*100
            
        else:
            data[i][j]=(data[i][j]-39)*100
            
#Manual parameter adjustment is required.

db = DBSCAN(eps=2.7, min_samples=2).fit(data)#, metric=haversine
core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
core_samples_mask[db.core_sample_indices_] = True
labels = db.labels_

#Write the results to a file.
path="outcome_"+fileName
with open(path,"w",newline="" , encoding="utf-8") as f:
    file = csv.writer(f)
    j=0
    reader=csv.reader(open(fileName,"rt",encoding="utf-8"))
    for i in reader:
        if(j==0):
            j+=1
            file.writerow(i)
        else:
            i.append(labels[j-1])
            j+=1
            file.writerow(i)


# In[ ]:





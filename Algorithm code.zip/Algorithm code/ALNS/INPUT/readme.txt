The example here is the result of setting up a transfer station based on the output of DBSCAN algorithm and splitting the long-distance corss-regional orders.
Then, put the orders in different regions in different files and input them into the algorithm for iteration.One file represents the order of a region.

In each file：

tab=0 ，color!=number  ,represents that this order is an ordinary order.
tab=0 , color=1 ,represents this order is a long-distance cross-regional order and it is from restaruant to transfer station.
tab=0 , color=0 ,represents this order is a long-distance cross-regional order and it is from  transfer station to customers.

Other contents are consistent with the description of the test instances.
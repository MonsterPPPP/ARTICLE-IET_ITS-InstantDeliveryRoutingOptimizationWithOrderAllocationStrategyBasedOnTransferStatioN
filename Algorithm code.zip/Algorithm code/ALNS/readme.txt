The entry of the program is in the main.java

The framework of the algorithm is located in main.java

The realization of initial solution and operator are in Couriers.java

The implementation of loss function in Courier.java

The reading of files are implemented in Reader.java

The value of the algorithm parameters are set in the Helper.java


Before running the code：
1.Set the location, number of files, and name of the example in main.java.
2.Set the parameters of the algorithm in Helper.java


